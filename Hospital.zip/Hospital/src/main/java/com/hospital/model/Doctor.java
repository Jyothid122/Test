package com.hospital.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

//mark class as an Entity 
@Entity
//defining class name as Table name
@Table
public class Doctor {
//mark id as primary key
	@Id
//defining id as column name
	@Column
	private int doctorId;
	
//	
//	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.DETACH)
//	//@JoinTable(name = "Patient")
//	private List<Patient> patient;
//	
//defining name as column name
	@Column
	private String name;


//	public List<Patient> getPatient() {
//		return patient;
//	}
//
//	public void setPatient(List<Patient> patient) {
//		this.patient = patient;
//	}

	//defining age as column name
	@Column
	private int age;
//defining email as column name
	@Column
	private String email;
	
	@Column
	private String address;
	
	

	

//	public Patient getPatient() {
//		return patient;
//	}
//
//	public void setPatient(Patient patient) {
//		this.patient = patient;
//	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}