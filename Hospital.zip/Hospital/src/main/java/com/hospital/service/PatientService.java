package com.hospital.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.model.Patient;
import com.hospital.repository.PatientRepository;

//defining the business logic
@Service
public class PatientService {
	@Autowired
	PatientRepository patientRepository;

//getting all Patient records
	public List<Patient> getAllPatient() {
		List<Patient> patients = new ArrayList<Patient>();
		Iterable<Patient>  patient1= patientRepository.findAll();
		for (Patient patient : patient1) {
			patients.add(patient);
		}
		return patients;
	}

//getting a specific record
	public Patient getPatientById(int id) {
		return patientRepository.findById(id).get();
	}

	public void saveOrUpdate(Patient patient) {
		patientRepository.save(patient);
	}

//deleting a specific record
	public void delete(int id) {
		patientRepository.deleteById(id);
	}
}