package com.hospital.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.model.Doctor;
import com.hospital.repository.DoctorRepository;

//defining the business logic
@Service
public class DoctorService {
	@Autowired
	DoctorRepository doctorRepository;

	// getting all doctor records
	public List<Doctor> getAllDoctor() {
		List<Doctor> doctors = new ArrayList<Doctor>();
		doctorRepository.findAll().forEach(doctor -> doctors.add(doctor));
		return doctors;
	}

//getting a specific record
	public Doctor getDoctorById(int id) {
		return doctorRepository.findById(id).get();
	}

	public void saveOrUpdate(Doctor doctor) {
		doctorRepository.save(doctor);
	}

//deleting a specific record
	public void delete(int id) {
		doctorRepository.deleteById(id);
	}
}