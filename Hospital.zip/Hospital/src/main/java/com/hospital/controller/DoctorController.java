package com.hospital.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.model.Doctor;
import com.hospital.service.DoctorService;

//creating RestController
@RestController
public class DoctorController {
//autowired the doctor Service class
	@Autowired
	DoctorService doctorService;

	// creating a get mapping that retrieves all the patients detail from the
	// database
	@GetMapping("/doctor")
	private List<Doctor> getAllDoctor() {
		return doctorService.getAllDoctor();
	}

//creating a get mapping that retrieves the detail of a specific doctor
	@GetMapping("/doctor/{id}")
	private Doctor getDoctor(@PathVariable("id") int id) {
		return doctorService.getDoctorById(id);
	}

//creating a delete mapping that deletes a specific Doctor
	@DeleteMapping("/doctor/{id}")
	private String deleteDoctor(@PathVariable("id") int id) {
		doctorService.delete(id);
		return id + "  Deleted Scuccessfully";
	}

//creating post mapping that post the Dctor detail in the database
	@PostMapping("/doctor")
	private String saveDoctor(@RequestBody Doctor doctor) {
		doctorService.saveOrUpdate(doctor);
		return doctor.getDoctorId() + " Created Successfully ";
	}
}
