package com.hospital.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hospital.model.Patient;
import com.hospital.service.PatientService;

//creating RestController
@RestController
public class PatientController {
//autowired the doctor Service class
	@Autowired
	PatientService patientService;

//creating a get mapping that retrieves all the patients detail from the database 
	@GetMapping("/patient")
	private List<Patient> getAllPatient() {
		return patientService.getAllPatient();
	}

//creating a get mapping that retrieves the detail of a specific patients
	@GetMapping("/patient/{id}")
	private Patient getDoctor(@PathVariable("id") int id) {
		return patientService.getPatientById(id);
	}

//creating a delete mapping that deletes a specific patients
	@DeleteMapping("/patient/{id}")
	private String deletePatient(@PathVariable("id") int id) {
		patientService.delete(id);
		return id + "  Deleted Scuccessfully";
	}

//creating post mapping that post the patients detail in the database
	@PostMapping("/patient")
	private String savePatient(@RequestBody Patient patient) {
		patientService.saveOrUpdate(patient);
		return patient.getPatientId() + " Created Successfully ";
	}
}
